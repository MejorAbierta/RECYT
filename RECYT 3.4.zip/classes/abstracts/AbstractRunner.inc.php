<?php
namespace CalidadFECYT\classes\abstracts;

abstract class AbstractRunner
{

}